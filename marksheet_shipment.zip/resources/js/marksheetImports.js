import '../css/assets/vendor/bootstrap/css/bootstrap.min.css';
import '../css/assets/vendor/bootstrap-icons/bootstrap-icons.css';
// import '../css/assets/vendor/aksFileUpload/aksFileUpload.min.css';
import '../css/assets/vendor/boxicons/css/boxicons.min.css';
import '../css/assets/vendor/remixicon/remixicon.css';
import '../css/assets/vendor/remixicon/remixicon.css';
// import '../css/assets/vendor/simple-datatables/style.css';
// import 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css';
// import '../css/assets/vendor/calender/fullcalendar.min.css';
// import '../css/assets/vendor/datepicker/datepicker.min.css';
// import 'https://unpkg.com/filepond@^4/dist/filepond.css';
import '../css/assets/css/style.css';

import '../css/assets/js/jquery-3.3.1.min.js';
import '../css/assets/vendor/bootstrap/js/bootstrap.bundle.min.js';
import '../css/assets/vendor/tinymce/tinymce.min.js';
import '../css/assets/js/main.js';
// import 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js';